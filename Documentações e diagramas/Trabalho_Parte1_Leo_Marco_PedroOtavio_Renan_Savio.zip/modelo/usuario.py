class Usuario:
    def __init__(self, nome: str, login: str, senha: str, tipo: str):
        self.nome   = nome
        self.login  = login 
        self.senha  = senha 
        self.tipo   = tipo
