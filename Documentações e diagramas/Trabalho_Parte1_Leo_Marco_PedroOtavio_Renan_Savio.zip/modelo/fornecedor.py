class Fornecedor:
    def __init__(self, nome: str, cnpj: str, telefone: str):
        self.nome     = nome
        self.cnpj     = cnpj
        self.telefone = telefone
